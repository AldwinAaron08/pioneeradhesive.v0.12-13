<?php
// kpi_groups.inc.php — shared KPI group partial
// Expects: $kpis (array with skuCount, lipasCount, cumulative, quantity, lipasPercent, volpasPercent)
//          $theme (string: 'weekly' | 'monthly' | 'yearly')

$_lp    = $kpis['lipasPercent']  ?? 0;
$_vp    = $kpis['volpasPercent'] ?? 0;
$_lpCls = $_lp >= 100 ? 'pct-green' : ($_lp >= 75 ? 'pct-amber' : 'pct-red');
$_vpCls = $_vp >= 100 ? 'pct-green' : ($_vp >= 75 ? 'pct-amber' : 'pct-red');
$_suffix = match($theme ?? 'weekly') {
    'monthly' => ' of the Month',
    'yearly'  => ' of the Year',
    default   => '',
};
?>
<div class="kpi-groups <?php echo htmlspecialchars($theme ?? 'weekly'); ?>">

    <?php /* ── Box A: LIPAS KPI ── */ ?>
    <div class="kpi-group kpi-group--lipas">
        <div class="kpi-group-header">
            <i class="fa fa-clipboard" aria-hidden="true"></i>
            <span class="kpi-group-label">LIPAS KPI</span>
        </div>
        <div class="kpi-group-body">
            <div class="kpi-item">
                <div class="kpi-item-label">LIPAS Count / Actual LIPAS<?php echo $_suffix; ?></div>
                <div class="kpi-item-value"><?php echo number_format($kpis['lipasCount']); ?></div>
            </div>
            <div class="kpi-item">
                <div class="kpi-item-label">Total SKU Count / Planned LIPAS<?php echo $_suffix; ?></div>
                <div class="kpi-item-value"><?php echo number_format($kpis['skuCount']); ?></div>
            </div>
            <div class="kpi-item kpi-item--pct">
                <div class="kpi-item-label">Total LIPAS %</div>
                <div class="kpi-item-value kpi-pct-value"><?php echo number_format($_lp, 1); ?>%</div>
                <div class="kpi-pct-bar-track">
                    <div class="kpi-pct-bar-fill" style="width:<?php echo $_lp; ?>%"></div>
                </div>
                <span class="kpi-pct-badge <?php echo $_lpCls; ?>"><?php echo number_format($_lp, 1); ?>%</span>
            </div>
        </div>
    </div>

    <?php /* ── Box B: VOLPAS KPI ── */ ?>
    <div class="kpi-group kpi-group--volpas">
        <div class="kpi-group-header">
            <i class="fa fa-bar-chart" aria-hidden="true"></i>
            <span class="kpi-group-label">VOLPAS KPI</span>
        </div>
        <div class="kpi-group-body">
            <div class="kpi-item">
                <div class="kpi-item-label">Cumulative Output / Actual VOLPAS<?php echo $_suffix; ?></div>
                <div class="kpi-item-value"><?php echo number_format($kpis['cumulative']); ?></div>
            </div>
            <div class="kpi-item">
                <div class="kpi-item-label">Quantity / Planned VOLPAS<?php echo $_suffix; ?></div>
                <div class="kpi-item-value"><?php echo number_format($kpis['quantity']); ?></div>
            </div>
            <div class="kpi-item kpi-item--pct">
                <div class="kpi-item-label">Total VOLPAS %</div>
                <div class="kpi-item-value kpi-pct-value"><?php echo number_format($_vp, 2); ?>%</div>
                <div class="kpi-pct-bar-track">
                    <div class="kpi-pct-bar-fill" style="width:<?php echo $_vp; ?>%"></div>
                </div>
                <span class="kpi-pct-badge <?php echo $_vpCls; ?>"><?php echo number_format($_vp, 2); ?>%</span>
            </div>
        </div>
    </div>

</div>
