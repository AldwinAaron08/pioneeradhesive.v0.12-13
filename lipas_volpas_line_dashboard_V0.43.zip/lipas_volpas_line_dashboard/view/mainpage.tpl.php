<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Dashboard</title>
    <link rel="stylesheet" href="css/mainpage.css">
    <link rel="icon" href="images/p_icon.png" type="image/png">
    <link rel="stylesheet" href="css/add_edit.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="js/mainpage.js" defer></script>
    <style>
        .lv-chart-toggle { display: flex; gap: 5px; }
        .lv-toggle-btn { padding: 8px 16px; border: 1px solid #cbd5e1; border-radius: 20px; background: white; color: #475569; font-weight: 600; cursor: pointer; transition: all 0.2s ease; font-size: 14px; }
        .lv-toggle-btn.active { background: #3b82f6; color: white; border-color: #3b82f6; }
        .lv-toggle-btn:hover:not(.active) { background: #f1f5f9; border-color: #94a3b8; }
        .filter-dropdown-disabled .filter-dropdown-btn { opacity: 0.5; cursor: not-allowed; }
        .filter-group select:disabled,
        .filter-group input:disabled,
        .filter-dropdown-btn:disabled { background: #f1f5f9; color: #94a3b8; cursor: not-allowed; }
    </style>
</head>
<body>
<div class="page-bg">
    <?php include __DIR__ . '/../templates/loader.php'; ?>

<header class="header">
    <h1>
        <img src="images/pioneerlogo.png" alt="Logo" style="height:1.2em; vertical-align:middle; margin-right:8px;">
         Production Dashboard
    </h1>
    <form id="logoutForm" method="post" action="logout.php" style="display:none;">
        <input type="hidden" name="logout" value="1">
    </form>
    <button type="button" class="logout-btn" onclick="openLogoutModal()">Logout</button>
</header>

<nav class="navbar user-welcome">
    <?php
    $userRoleIcons = ['system_admin' => 'fa-shield', 'data_entry' => 'fa-pencil', 'viewer' => 'fa-eye'];
    $userRoleLabels = ['system_admin' => 'System Admin', 'data_entry' => 'Data Entry', 'viewer' => 'Viewer'];
    $currentRoleIcon = $userRoleIcons[$_SESSION['role']] ?? 'fa-user';
    $currentRoleLabel = $userRoleLabels[$_SESSION['role']] ?? ucfirst($_SESSION['role'] ?? '');
    ?>
    <span><i class="fa fa-user-circle"></i> Welcome, <?php echo htmlspecialchars($_SESSION['user']); ?> &nbsp;|&nbsp; <i class="fa <?php echo $currentRoleIcon; ?>"></i> <?php echo $currentRoleLabel; ?></span>
</nav>

<nav class="navbar">
    <div class="dropdown">
        <button class="dropbtn">Dashboard Reports <i class="fa fa-caret-down"></i></button>
        <div class="dropdown-content">
            <a href="?report=weekly"><i class="fa fa-bar-chart"></i> Weekly Report</a>
            <a href="?report=monthly"><i class="fa fa-line-chart"></i> Monthly Report</a>
            <a href="?report=yearly"><i class="fa fa-area-chart"></i> Yearly Report</a>
            <a href="?report=lipas_volpas"><i class="fa fa-pie-chart"></i> LIPAS VOLPAS Report</a>
        </div>
    </div>
</nav>

<div class="wrapper">
    <!-- Overlay — dims main content when sidebar open on mobile -->
    <div id="sidebarOverlay" class="sidebar-overlay"></div>

    <aside class="sidebar sticky-sidebar" id="appSidebar">
        <!-- Hamburger toggle — sits above nav links -->
        <div class="sidebar-toggle-wrap">
            <button type="button" id="sidebarToggleBtn" class="sidebar-toggle-btn"
                    aria-label="Toggle sidebar" aria-expanded="true" aria-controls="appSidebar">
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
            </button>
        </div>
        <ul>
            <li class="active"><a href="mainpage.php" data-tooltip="Dashboard">
                <i class="fa fa-tachometer"></i> <span class="sidebar-text">Dashboard Page</span>
            </a></li>
            <li><a href="add_edit.php" data-tooltip="Production Records">
                <i class="fa fa-table"></i> <span class="sidebar-text">Manage Production Records</span>
            </a></li>
            <li><a href="manage_report.php" data-tooltip="Line Report">
                <i class="fa fa-file-text-o"></i> <span class="sidebar-text">Line Report Records &amp; LIPAS VOLPAS</span>
            </a></li>
            <?php if ($_SESSION['role'] === 'system_admin'): ?>
                <li class="admin-section-label"><span class="sidebar-text">Admin Access</span></li>
                <li>
                    <a href="manage_users.php" data-tooltip="User Management">
                        <i class="fa fa-users"></i> <span class="sidebar-text">User Management</span>
                        <?php if ($pendingUsersCount > 0): ?>
                            <span class="mu-nav-badge"><?php echo $pendingUsersCount; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li><a href="import_data.php" data-tooltip="Import Records">
                    <i class="fa fa-upload"></i> <span class="sidebar-text">Import Records</span>
                </a></li>
                <li><a href="audit_log.php" data-tooltip="Audit Trail">
                    <i class="fa fa-history"></i> <span class="sidebar-text">Audit Trail</span>
                </a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <main class="main-content">

        <?php if ($report == 'weekly'): ?>
            <h2>Weekly Report</h2>
            <div class="report-filters">
                <form method="get" id="weeklyForm">
                    <input type="hidden" name="report" value="weekly">
                    <div class="filter-group"><label>Team</label><select name="team" onchange="cascadeWeekly(this)"><option value="">All Teams</option><option value="A" <?php echo ($filterTeam == 'A') ? 'selected' : ''; ?>>Team A</option><option value="B" <?php echo ($filterTeam == 'B') ? 'selected' : ''; ?>>Team B</option><option value="C" <?php echo ($filterTeam == 'C') ? 'selected' : ''; ?>>Team C</option></select></div>
                    <div class="filter-group"><label>Year</label><select name="year" onchange="cascadeWeekly(this)" <?php echo empty($filterTeam) ? 'disabled' : ''; ?>><?php for ($y = date('Y')-2; $y <= date('Y')+2; $y++): ?><option value="<?php echo $y; ?>" <?php echo ($filterYear == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
                    <div class="filter-group"><label>Month</label><select name="month" onchange="cascadeWeekly(this)" <?php echo empty($filterYear) ? 'disabled' : ''; ?>><?php foreach ($months as $m): ?><option value="<?php echo $m; ?>" <?php echo ($filterMonth == $m) ? 'selected' : ''; ?>><?php echo $m; ?></option><?php endforeach; ?></select></div>
                    <div class="filter-group">
                        <label>Prod. Days</label>
                        <div class="filter-dropdown <?php echo (!$filterTeam || !$filterMonth) ? 'filter-dropdown-disabled' : ''; ?>" id="opsDaysDropdown">
                            <button type="button" class="filter-dropdown-btn" <?php echo (!$filterTeam || !$filterMonth) ? 'disabled' : ''; ?> onclick="toggleOpsDaysDropdown(event)">
                                <?php
                                    if (!empty($selectedOpsDays)) {
                                        $labels = [];
                                        foreach ($selectedOpsDays as $v) {
                                            $p = explode('|', $v, 2);
                                            $labels[] = $p[0] ? date('M d', strtotime($p[0])) . '–' . date('M d', strtotime($p[1])) : $v;
                                        }
                                        echo htmlspecialchars(implode(', ', $labels), ENT_QUOTES);
                                    } else {
                                        echo 'All';
                                    }
                                ?>
                                <span class="arrow">▾</span>
                            </button>
                            <div class="filter-dropdown-panel" id="opsDaysDropdownPanel">
                                <label class="filter-checkbox-item select-all-item"><input type="checkbox" id="selectAllOpsDays" onclick="toggleAllOpsDays(this)"> <span>Select All</span></label>
                                <hr class="filter-divider">
                                <?php foreach ($opsDaysOptions as $od):
                                    $val = $od['OPERATING_DAYS_START'] . '|' . $od['OPERATING_DAYS_END'];
                                    $lbl = date('M d', strtotime($od['OPERATING_DAYS_START'])) . ' – ' . date('M d, Y', strtotime($od['OPERATING_DAYS_END']));
                                ?>
                                <label class="filter-checkbox-item">
                                    <input type="checkbox" name="ops_days[]" value="<?php echo htmlspecialchars($val); ?>"
                                        <?php echo in_array($val, $selectedOpsDays) ? 'checked' : ''; ?>
                                        onchange="this.form.submit()">
                                    <span><?php echo htmlspecialchars($lbl); ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="filter-group">
                        <label>Line</label>
                        <div class="filter-dropdown <?php echo empty($opsDaysOptions) ? 'filter-dropdown-disabled' : ''; ?>" id="lineDropdown">
                            <button type="button" class="filter-dropdown-btn" <?php echo empty($opsDaysOptions) ? 'disabled' : ''; ?> onclick="toggleLineDropdown(event)">
                                <?php echo !empty($filterLines) ? htmlspecialchars(implode(', ', $filterLines), ENT_QUOTES) : 'All Lines'; ?> <span class="arrow">▾</span>
                            </button>
                            <div class="filter-dropdown-panel" id="lineDropdownPanel">
                                <label class="filter-checkbox-item select-all-item"><input type="checkbox" id="selectAllLines" onclick="toggleAllProdLines(this)"> <span>Select All</span></label>
                                <hr class="filter-divider">
                                <?php foreach ($weeklyLineOptions as $line): ?>
                                <label class="filter-checkbox-item"><input type="checkbox" name="line[]" value="<?php echo htmlspecialchars($line); ?>" <?php echo in_array($line, $filterLines) ? 'checked' : ''; ?> onchange="this.form.submit()"><span><?php echo htmlspecialchars($line); ?></span></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <?php $kpis = $weeklyKPIs; $theme = 'weekly'; ?>
            <?php include __DIR__ . '/kpi_groups.inc.php'; ?>

            <div class="chart-card">
                <h3>VOLPAS Actual vs VOLPAS Planned</h3>
                <canvas id="cumulativeChart"></canvas>
            </div>


        <?php elseif ($report == 'monthly'): ?>
            <h2 class="report-heading-monthly">Monthly Report</h2>
            <div class="report-filters">
                <form method="get" id="monthlyForm">
                    <input type="hidden" name="report" value="monthly">
                    <div class="filter-group"><label>Team</label><select name="team" onchange="cascadeMonthly(this)"><option value="">All Teams</option><option value="A" <?php echo ($filterTeam == 'A') ? 'selected' : ''; ?>>Team A</option><option value="B" <?php echo ($filterTeam == 'B') ? 'selected' : ''; ?>>Team B</option><option value="C" <?php echo ($filterTeam == 'C') ? 'selected' : ''; ?>>Team C</option></select></div>
                    <div class="filter-group"><label>Year</label><select name="year" onchange="cascadeMonthly(this)" <?php echo empty($filterTeam) ? 'disabled' : ''; ?>><?php for ($y = date('Y')-2; $y <= date('Y')+2; $y++): ?><option value="<?php echo $y; ?>" <?php echo ($filterYear == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
                    <div class="filter-group"><label>Month</label><select name="month" onchange="cascadeMonthly(this)" <?php echo empty($filterYear) ? 'disabled' : ''; ?>><option value="" <?php echo ($filterMonth === '') ? 'selected' : ''; ?>>All Months</option><?php foreach ($months as $m): ?><option value="<?php echo $m; ?>" <?php echo ($filterMonth == $m) ? 'selected' : ''; ?>><?php echo ucfirst(strtolower($m)); ?></option><?php endforeach; ?></select></div>
                    <div class="filter-group">
                        <label>Line</label>
                        <div class="filter-dropdown <?php echo empty($filterMonth) ? 'filter-dropdown-disabled' : ''; ?>" id="monthlyLineDropdown">
                            <button type="button" class="filter-dropdown-btn" <?php echo empty($filterMonth) ? 'disabled' : ''; ?> onclick="toggleMonthlyLineDropdown(event)">
                                <?php echo !empty($filterLines) ? htmlspecialchars(implode(', ', $filterLines), ENT_QUOTES) : 'All Lines'; ?> <span class="arrow">▾</span>
                            </button>
                            <div class="filter-dropdown-panel" id="monthlyLineDropdownPanel">
                                <label class="filter-checkbox-item select-all-item"><input type="checkbox" id="selectAllMonthlyLines" onclick="toggleAllMonthlyLines(this)"> <span>Select All</span></label>
                                <hr class="filter-divider">
                                <?php foreach ($monthlyLineOptions as $line): ?>
                                <label class="filter-checkbox-item"><input type="checkbox" name="line[]" value="<?php echo htmlspecialchars($line); ?>" <?php echo in_array($line, $filterLines) ? 'checked' : ''; ?> onchange="this.form.submit()"><span><?php echo htmlspecialchars($line); ?></span></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <?php $kpis = $monthlyKPIs; $theme = 'monthly'; ?>
            <?php include __DIR__ . '/kpi_groups.inc.php'; ?>

            <div class="chart-card monthly"><h3>VOLPAS Actual vs VOLPAS Planned – <?php echo htmlspecialchars($filterMonth) . ' ' . htmlspecialchars($filterYear); ?></h3><canvas id="monthlyCumChart"></canvas></div>

        <?php elseif ($report == 'yearly'): ?>
            <h2 class="report-heading-yearly">Yearly Report</h2>
            <div class="report-filters">
                <form method="get" id="yearlyForm">
                    <input type="hidden" name="report" value="yearly">
                    <div class="filter-group"><label>Team</label><select name="team" onchange="cascadeYearly(this)"><option value="">All Teams</option><option value="A" <?php echo ($filterTeam == 'A') ? 'selected' : ''; ?>>Team A</option><option value="B" <?php echo ($filterTeam == 'B') ? 'selected' : ''; ?>>Team B</option><option value="C" <?php echo ($filterTeam == 'C') ? 'selected' : ''; ?>>Team C</option></select></div>
                    <div class="filter-group"><label>Year</label><select name="year" onchange="cascadeYearly(this)" <?php echo empty($filterTeam) ? 'disabled' : ''; ?>><?php for ($y = date('Y')-2; $y <= date('Y')+2; $y++): ?><option value="<?php echo $y; ?>" <?php echo ($filterYear == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
                    <div class="filter-group">
                        <label>Line</label>
                        <div class="filter-dropdown <?php echo empty($filterYear) ? 'filter-dropdown-disabled' : ''; ?>" id="yearlyLineDropdown">
                            <button type="button" class="filter-dropdown-btn" <?php echo empty($filterYear) ? 'disabled' : ''; ?> onclick="toggleYearlyLineDropdown(event)">
                                <?php echo !empty($filterLines) ? htmlspecialchars(implode(', ', $filterLines), ENT_QUOTES) : 'All Lines'; ?> <span class="arrow">▾</span>
                            </button>
                            <div class="filter-dropdown-panel" id="yearlyLineDropdownPanel">
                                <label class="filter-checkbox-item select-all-item"><input type="checkbox" id="selectAllYearlyLines" onclick="toggleAllYearlyLines(this)"> <span>Select All</span></label>
                                <hr class="filter-divider">
                                <?php foreach ($yearlyLineOptions as $line): ?>
                                <label class="filter-checkbox-item"><input type="checkbox" name="line[]" value="<?php echo htmlspecialchars($line); ?>" <?php echo in_array($line, $filterLines) ? 'checked' : ''; ?> onchange="this.form.submit()"><span><?php echo htmlspecialchars($line); ?></span></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <?php $kpis = $yearlyKPIs; $theme = 'yearly'; ?>
            <?php include __DIR__ . '/kpi_groups.inc.php'; ?>

            <div class="chart-grid-2col">
                <div class="chart-card yearly"><h3>VOLPAS Actual vs VOLPAS Planned – <?php echo htmlspecialchars($filterYear); ?></h3><canvas id="yearlyCumChart"></canvas></div>
            </div>

        <?php elseif ($report == 'lipas_volpas'): ?>
            <h2 class="report-heading-lv">LIPAS VOLPAS Report</h2>
            <div class="report-filters lv-filters">
                <form method="get" id="lvForm">
                    <input type="hidden" name="report" value="lipas_volpas">
                    <div class="filter-group"><label>Period</label><select name="lv_period" onchange="lvHandlePeriodChange(this)"><option value="weekly" <?php echo ($lvPeriod === 'weekly') ? 'selected' : ''; ?>>Weekly</option><option value="monthly" <?php echo ($lvPeriod === 'monthly') ? 'selected' : ''; ?>>Monthly</option></select></div>
                    <div class="filter-group"><label>Year</label><select name="lv_year" onchange="this.form.submit()"><?php for ($y = date('Y')-2; $y <= date('Y')+2; $y++): ?><option value="<?php echo $y; ?>" <?php echo ($lvYear == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
                    <div class="filter-group lv-month-group" id="lvMonthGroup" <?php echo ($lvPeriod === 'weekly') ? 'style="display:none"' : ''; ?>><label>Month</label><select name="lv_month" onchange="this.form.submit()"><option value="" <?php echo ($lvMonth === '') ? 'selected' : ''; ?>>All Months</option><?php foreach ($lvAllMonths as $m): ?><option value="<?php echo $m; ?>" <?php echo ($lvMonth === $m) ? 'selected' : ''; ?>><?php echo ucfirst(strtolower($m)); ?></option><?php endforeach; ?></select></div>
                    <div class="filter-group lv-week-group" id="lvWeekGroup" <?php echo ($lvPeriod !== 'weekly') ? 'style="display:none"' : ''; ?>><label>Week</label><select name="lv_week" onchange="this.form.submit()"><option value="all" <?php echo ($lvWeek === 'all') ? 'selected' : ''; ?>>All Weeks</option><?php for ($w = 1; $w <= 5; $w++): ?><option value="<?php echo $w; ?>" <?php echo ($lvWeek == $w) ? 'selected' : ''; ?>>Week <?php echo $w; ?></option><?php endfor; ?></select></div>
                    <div class="filter-group"><label>Team</label><select name="lv_team" onchange="this.form.submit()"><option value="" <?php echo ($lvTeam === '') ? 'selected' : ''; ?>>All Teams</option><option value="A" <?php echo ($lvTeam === 'A') ? 'selected' : ''; ?>>Team A</option><option value="B" <?php echo ($lvTeam === 'B') ? 'selected' : ''; ?>>Team B</option><option value="C" <?php echo ($lvTeam === 'C') ? 'selected' : ''; ?>>Team C</option></select></div>
                    <div class="filter-group"><label>Line</label><select name="lv_line" onchange="this.form.submit()"><option value="" <?php echo ($lvLine === '') ? 'selected' : ''; ?>>All Lines</option><?php foreach ($lvLineOptions as $ln): ?><option value="<?php echo htmlspecialchars($ln); ?>" <?php echo ($lvLine === $ln) ? 'selected' : ''; ?>><?php echo htmlspecialchars($ln); ?></option><?php endforeach; ?></select></div>
                    <div class="filter-group"><label>Dataset</label><select name="lv_dataset" onchange="this.form.submit()"><option value="both" <?php echo ($lvDataset === 'both') ? 'selected' : ''; ?>>LIPAS + VOLPAS</option><option value="lipas" <?php echo ($lvDataset === 'lipas') ? 'selected' : ''; ?>>LIPAS Only</option><option value="volpas" <?php echo ($lvDataset === 'volpas') ? 'selected' : ''; ?>>VOLPAS Only</option></select></div>
                    <div class="filter-group"><label>Chart Type</label><div class="lv-chart-toggle"><button type="submit" name="lv_charttype" value="bar" class="lv-toggle-btn <?php echo ($lvChartType === 'bar') ? 'active' : ''; ?>">Bar</button><button type="submit" name="lv_charttype" value="pie" class="lv-toggle-btn <?php echo ($lvChartType === 'pie') ? 'active' : ''; ?>">Pie</button></div></div>
                </form>
            </div>

            <?php
                $lvKpiContext = $lvYear;
                if ($lvPeriod === 'monthly') {
                    $lvKpiContext .= !empty($lvMonth) ? ' – ' . ucfirst(strtolower($lvMonth)) : '';
                    $lvKpiContext .= ' – Monthly';
                } else {
                    $lvKpiContext .= !empty($lvMonth) ? ' – ' . ucfirst(strtolower($lvMonth)) : '';
                    $lvKpiContext .= ' – Weekly';
                    $lvKpiContext .= ($lvWeek !== 'all') ? ' – Week ' . (int)$lvWeek : '';
                }
            ?>
            <div class="kpi-grid lv-kpi-grid">
                <?php if ($lvDataset !== 'volpas'): ?>
                <div class="kpi-card lv-lipas-card"><div class="label">LIPAS Plan <small>(<?php echo htmlspecialchars($lvKpiContext); ?>)</small></div><div class="value"><?php echo number_format($lvSummaryData['lipasTotalPlan'] ?? 0); ?></div></div>
                <div class="kpi-card lv-lipas-card"><div class="label">LIPAS Actual <small>(<?php echo htmlspecialchars($lvKpiContext); ?>)</small></div><div class="value"><?php echo number_format($lvSummaryData['lipasTotalActual'] ?? 0); ?></div><div class="lv-percentage <?php echo ($lvSummaryData['lipasPercentage'] ?? 0) >= 100 ? 'pct-green' : 'pct-red'; ?>"><?php echo number_format($lvSummaryData['lipasPercentage'] ?? 0, 2); ?>%</div></div>
                <?php endif; ?>
                <?php if ($lvDataset !== 'lipas'): ?>
                <div class="kpi-card lv-volpas-card"><div class="label">VOLPAS Plan <small>(<?php echo htmlspecialchars($lvKpiContext); ?>)</small></div><div class="value"><?php echo number_format($lvSummaryData['volpasTotalPlan'] ?? 0); ?></div></div>
                <div class="kpi-card lv-volpas-card"><div class="label">VOLPAS Actual <small>(<?php echo htmlspecialchars($lvKpiContext); ?>)</small></div><div class="value"><?php echo number_format($lvSummaryData['volpasTotalActual'] ?? 0); ?></div><div class="lv-percentage <?php echo ($lvSummaryData['volpasPercentage'] ?? 0) >= 100 ? 'pct-green' : 'pct-red'; ?>"><?php echo number_format($lvSummaryData['volpasPercentage'] ?? 0, 2); ?>%</div></div>
                <?php endif; ?>
            </div>

            <?php if ($lvDataset == 'both'): ?>
                <h3>LIPAS</h3><div class="chart-card lv"><canvas id="lvLipasChart"></canvas></div>
                <h3>VOLPAS</h3><div class="chart-card lv"><canvas id="lvVolpasChart"></canvas></div>
            <?php elseif ($lvDataset == 'lipas'): ?>
                <h3>LIPAS</h3><div class="chart-card lv"><canvas id="lvLipasChart"></canvas></div>
            <?php elseif ($lvDataset == 'volpas'): ?>
                <h3>VOLPAS</h3><div class="chart-card lv"><canvas id="lvVolpasChart"></canvas></div>
            <?php endif; ?>

        <?php endif; ?>

        <?php
        // ── Analytics section — shown for all 4 report types when data exists ──
        $_teamColors = [
            'A' => ['bg'=>'#dbeafe','text'=>'#1e40af','bar'=>'#3b82f6','name'=>'Team A'],
            'B' => ['bg'=>'#ede9fe','text'=>'#5b21b6','bar'=>'#7c3aed','name'=>'Team B'],
            'C' => ['bg'=>'#d1fae5','text'=>'#065f46','bar'=>'#059669','name'=>'Team C'],
        ];
        $_hasAnalytics = !empty($analyticsTeamLines);
        $_contextLabel = '';
        if ($report === 'weekly')       $_contextLabel = htmlspecialchars($filterMonth) . ' ' . htmlspecialchars($filterYear) . ' — Weekly';
        elseif ($report === 'monthly')  $_contextLabel = htmlspecialchars($filterMonth) . ' ' . htmlspecialchars($filterYear) . ' — Monthly';
        elseif ($report === 'yearly')   $_contextLabel = htmlspecialchars($filterYear) . ' — Yearly';
        elseif ($report === 'lipas_volpas') {
            $_contextLabel = 'LIPAS VOLPAS — ' . htmlspecialchars($_lvYear ?? date('Y'));
            if (!empty($_lvMonth)) $_contextLabel .= ' · ' . ucfirst(strtolower($_lvMonth));
            $_contextLabel .= ' · sourced from LIPAS &amp; VOLPAS records';
        }

        // Max actual across all lines (for bar scaling)
        $_maxActual = 1;
        foreach ($analyticsLineRanking as $_lr) {
            if ($_lr['actual'] > $_maxActual) $_maxActual = $_lr['actual'];
        }
        // Max planned per team (for VOLPAS bar scaling)
        $_maxPlanned = 1;
        foreach ($analyticsVolpasByTeam as $_vt) {
            if ($_vt['planned'] > $_maxPlanned) $_maxPlanned = $_vt['planned'];
        }
        ?>

        <?php if ($_hasAnalytics): ?>
        <section class="analytics-section">

            <div class="analytics-header">
                <div>
                    <h2 class="analytics-title"><i class="fa fa-bar-chart"></i> Team &amp; Line Analytics</h2>
                    <p class="analytics-sub"><?php echo $_contextLabel; ?></p>
                </div>
            </div>

            <!-- ── Row 1: Team cards ───────────────────────────────── -->
            <div class="analytics-team-row">
            <?php foreach ($_teamColors as $_tk => $_tc):
                if (!isset($analyticsTeamLines[$_tk])) continue;
                $_lines   = $analyticsTeamLines[$_tk];
                $_vt      = $analyticsVolpasByTeam[$_tk] ?? ['actual'=>0,'planned'=>0];
                $_lineMax = !empty($_lines) ? max(array_column(array_values($_lines), 'actual') ?: [1]) : 1;
                $_totalSku   = array_sum(array_column(array_values($_lines), 'skuCount'));
                $_totalLipas = array_sum(array_column(array_values($_lines), 'lipasCount'));
                $_pctActual  = $_vt['planned'] > 0 ? min(100, round($_vt['actual'] / $_vt['planned'] * 100)) : 0;
            ?>
                <div class="analytics-team-card">
                    <div class="atc-header" style="border-left: 4px solid <?php echo $_tc['bar']; ?>">
                        <div class="atc-header-left">
                            <span class="atc-name"><?php echo $_tc['name']; ?></span>
                            <span class="atc-badge" style="background:<?php echo $_tc['bg']; ?>;color:<?php echo $_tc['text']; ?>">
                                <?php echo count($_lines); ?> Line<?php echo count($_lines) !== 1 ? 's' : ''; ?>
                            </span>
                        </div>
                        <div class="atc-attainment">
                            <div class="atc-attainment-ring">
                                <svg viewBox="0 0 36 36" class="atc-ring-svg">
                                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="#e2e8f0" stroke-width="3"/>
                                    <circle cx="18" cy="18" r="15.9" fill="none"
                                        stroke="<?php echo $_tc['bar']; ?>" stroke-width="3"
                                        stroke-dasharray="<?php echo $_pctActual; ?> 100"
                                        stroke-linecap="round"
                                        transform="rotate(-90 18 18)"/>
                                </svg>
                                <span class="atc-ring-label" style="color:<?php echo $_tc['bar']; ?>"><?php echo $_pctActual; ?>%</span>
                            </div>
                            <span class="atc-attainment-txt">Attainment</span>
                        </div>
                    </div>

                    <div class="atc-kpis">
                        <div class="atc-kpi atc-kpi--actual">
                            <div class="atc-kpi-icon" style="color:<?php echo $_tc['bar']; ?>"><i class="fa fa-check-circle"></i></div>
                            <div class="atc-kpi-val"><?php echo number_format($_vt['actual']); ?></div>
                            <div class="atc-kpi-lbl">Actual VOLPAS</div>
                        </div>
                        <div class="atc-kpi atc-kpi--planned">
                            <div class="atc-kpi-icon" style="color:#94a3b8"><i class="fa fa-flag-o"></i></div>
                            <div class="atc-kpi-val"><?php echo number_format($_vt['planned']); ?></div>
                            <div class="atc-kpi-lbl">Planned VOLPAS</div>
                        </div>
                        <?php if ($report !== 'lipas_volpas'): ?>
                        <div class="atc-kpi atc-kpi--lipas">
                            <div class="atc-kpi-icon" style="color:#8b5cf6"><i class="fa fa-tags"></i></div>
                            <div class="atc-kpi-val"><?php echo number_format($_totalLipas); ?></div>
                            <div class="atc-kpi-lbl">Actual LIPAS</div>
                        </div>
                        <div class="atc-kpi atc-kpi--sku">
                            <div class="atc-kpi-icon" style="color:#0ea5e9"><i class="fa fa-cubes"></i></div>
                            <div class="atc-kpi-val"><?php echo number_format($_totalSku); ?></div>
                            <div class="atc-kpi-lbl">Planned LIPAS</div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="atc-lines-header">
                        <span>Line</span><span>Output</span><span>Actual</span>
                    </div>
                    <div class="atc-lines">
                    <?php foreach ($_lines as $_ln => $_ld):
                        $_pct = $_lineMax > 0 ? min(100, round($_ld['actual'] / $_lineMax * 100)) : 0;
                    ?>
                        <div class="atc-line-row">
                            <span class="atc-line-name"><?php echo htmlspecialchars($_ln); ?></span>
                            <div class="atc-line-track">
                                <div class="atc-line-fill" style="width:<?php echo $_pct; ?>%;background:<?php echo $_tc['bar']; ?>"></div>
                            </div>
                            <span class="atc-line-val"><?php echo number_format($_ld['actual']); ?></span>
                        </div>
                    <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>

            <!-- ── Row 2: Line ranking + VOLPAS by team ───────────── -->
            <div class="analytics-bottom-row">

                <!-- Line ranking -->
                <div class="analytics-panel analytics-ranking">
                    <div class="ap-header">
                        <div>
                            <div class="ap-title"><i class="fa fa-trophy"></i> Line Output Ranking</div>
                            <div class="ap-sub">All teams · sorted by Actual Output</div>
                        </div>
                    </div>
                    <?php if (empty($analyticsLineRanking)): ?>
                        <p class="analytics-empty">No data available.</p>
                    <?php else: ?>
                    <?php foreach ($analyticsLineRanking as $_rank => $_lr):
                        $_tc2  = $_teamColors[$_lr['team']] ?? ['bg'=>'#e2e8f0','text'=>'#475569','bar'=>'#64748b'];
                        $_pct2 = $_maxActual > 0 ? min(100, round($_lr['actual'] / $_maxActual * 100)) : 0;
                    ?>
                        <div class="ranking-row">
                            <span class="ranking-pos"><?php echo $_rank + 1; ?></span>
                            <span class="ranking-team-badge" style="background:<?php echo $_tc2['bg']; ?>;color:<?php echo $_tc2['text']; ?>">
                                <?php echo htmlspecialchars($_lr['team']); ?>
                            </span>
                            <span class="ranking-line"><?php echo htmlspecialchars($_lr['line']); ?></span>
                            <div class="ranking-track">
                                <div class="ranking-fill" style="width:<?php echo $_pct2; ?>%;background:<?php echo $_tc2['bar']; ?>"></div>
                            </div>
                            <span class="ranking-val"><?php echo number_format($_lr['actual']); ?></span>
                        </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- VOLPAS by team + shift breakdown (weekly only) -->
                <div class="analytics-right-col">

                    <!-- VOLPAS plan vs actual per team -->
                    <div class="analytics-panel analytics-volpas-panel">
                        <div class="ap-header">
                            <div class="ap-title"><i class="fa fa-area-chart"></i> <?php echo $report === 'lipas_volpas' ? 'LIPAS + VOLPAS' : 'VOLPAS'; ?> Actual vs Planned</div>
                            <div class="ap-sub">By team</div>
                        </div>
                        <div class="vp-header-row">
                            <span>Team</span><span>Output</span>
                            <span class="vp-num-head">Actual</span>
                            <span class="vp-num-head">Planned</span>
                        </div>
                        <?php foreach ($_teamColors as $_tk => $_tc):
                            if (!isset($analyticsVolpasByTeam[$_tk])) continue;
                            $_vd    = $analyticsVolpasByTeam[$_tk];
                            $_apct  = $_maxPlanned > 0 ? min(100, round($_vd['actual']  / $_maxPlanned * 100)) : 0;
                            $_ppct  = $_maxPlanned > 0 ? min(100, round($_vd['planned'] / $_maxPlanned * 100)) : 0;
                            $_vpct  = $_vd['planned'] > 0 ? min(100, round($_vd['actual'] / $_vd['planned'] * 100)) : 0;
                        ?>
                        <div class="vp-row">
                            <div class="vp-team-info">
                                <span class="vp-team-dot" style="background:<?php echo $_tc['bar']; ?>"></span>
                                <span class="vp-team-name"><?php echo $_tc['name']; ?></span>
                            </div>
                            <div class="vp-bars">
                                <div class="vp-bar-track"><div class="vp-bar-actual" style="width:<?php echo $_apct; ?>%;background:<?php echo $_tc['bar']; ?>"></div></div>
                                <div class="vp-bar-track vp-bar-plan-track"><div class="vp-bar-plan" style="width:<?php echo $_ppct; ?>%"></div></div>
                            </div>
                            <span class="vp-num"><?php echo number_format($_vd['actual']); ?></span>
                            <span class="vp-num vp-num-planned"><?php echo number_format($_vd['planned']); ?></span>
                        </div>
                        <div class="vp-attainment-strip">
                            <span class="vp-attainment-label">Attainment</span>
                            <div class="vp-attainment-track">
                                <div class="vp-attainment-fill" style="width:<?php echo $_vpct; ?>%;background:<?php echo $_tc['bar']; ?>"></div>
                            </div>
                            <span class="vp-attainment-pct" style="color:<?php echo $_vpct >= 100 ? '#059669' : '#dc2626'; ?>"><?php echo $_vpct; ?>%</span>
                        </div>
                        <?php endforeach; ?>
                    </div>



                </div>
            </div>

        </section>
        <?php endif; ?>

    </main>
</div>

<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> Production Monitoring System</p>
</footer>

</div>

<!-- LOGOUT CONFIRMATION MODAL -->
<div id="logoutModal" class="logout-modal-overlay" style="display:none;">
    <div class="logout-modal-box">
        <h3><i class="fa fa-sign-out"></i> Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="logout-modal-actions">
            <button class="btn-cancel" onclick="closeLogoutModal()"><i class="fa fa-times"></i> No</button>
            <button class="btn-logout-yes" onclick="confirmLogout()"><i class="fa fa-check"></i> Yes</button>
        </div>
    </div>
</div>

<script>
// Dynamic data passed to the JS file
var cumulativeChartData = <?php echo json_encode($cumulativeChartData); ?>;
var monthlyChartData    = <?php echo json_encode($monthlyChartData); ?>;
var monthlyCumChartData = <?php echo json_encode($monthlyCumChartData); ?>;
var yearlyChartData     = <?php echo json_encode($yearlyChartData); ?>;
var yearlyCumChartData  = <?php echo json_encode($yearlyCumChartData); ?>;
var lipasChartData      = <?php echo json_encode($lipasChartData); ?>;
var volpasChartData     = <?php echo json_encode($volpasChartData); ?>;
var lvDataset           = <?php echo json_encode($lvDataset ?? 'both'); ?>;
var lvChartType         = <?php echo json_encode($lvChartType ?? 'bar'); ?>;
</script>
</body>
</html>